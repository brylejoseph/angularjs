'use strict';

// Declare app level module which depends on views, and components
var app = angular.module('myApp', []);

app.controller('itunesCtrl', itunesCtrl);

//search.$inject = [ 'DataService' ];
itunesCtrl.$inject = ['SearchService','$sce'];
function itunesCtrl(SearchService,$sce){
        var vm = this;
        vm.searchItem = null;
        vm.artist= {};
        vm.result = [];
        vm.message = null;
        
          vm.search = function() {
          SearchService.fetch(vm.searchItem).
            success(function(data){
              vm.result = data;
            }).
            error(function(data){
              vm.result = data;
            });
        }; 
       vm.addResult =[];
        var search2URL = 'https://itunes.apple.com/lookup';
        var postURL =  'https://cs-itunes.appspot.com/api/favorite/roaneebryle.joseph@cloudsherpas.com';
        vm.addFavorite = function(artist){ 
          var artistFave = angular.toJson(artist);
          SearchService.addFavorite(artist);
          vm.message = "You have added a new favorite.";

        }; 

        vm.favorite ={};
        vm.favoriteList = [];
        
        vm.showFavorites = function(){
          SearchService.showFavorites().
            success(function(data){
              console.log("favorites success");
              vm.favoriteList = data;
              console.log(vm.favoriteList.artistName);
            }).
            error(function(data){
              console.log("favorites error");
              vm.favoriteList = data;
            });
        };

        vm.removeFavorite = function(id,index){
            SearchService.removeFavorite(id);
            vm.favoriteList.splice(index,1);
            vm.message = "You deleted a favorite";
          };

        vm.trustResource = function(url){
           return $sce.trustAsResourceUrl(url);
          };
        }

app.factory('SearchService', SearchService);
SearchService.$inject = ['$http'];
function SearchService($http){
  var service = this;
  var favoritesURL =  'https://cs-itunes.appspot.com/api/favorite/roaneebryle.joseph@cloudsherpas.com';
  var URL = 'https://itunes.apple.com/search';
  // var request = function(searchItem) {
  var request = function(searchItem) { 
      console.log("searchItem:"+searchItem);
      return $http.jsonp(URL, {
          params: {
              "callback": "JSON_CALLBACK",
              "term": searchItem,
              "media":"music",
              "entity":"song",
              "limit": 10
          }
      })
  };

    return {
      fetch: request,
      addFavorite: function(artist){
        $http.post(favoritesURL,artist);
      },
      showFavorites: function(){
        return $http.get(favoritesURL);
      },
      removeFavorite: function(id){
        return $http.delete(favoritesURL+"/"+id);
      }
    }

}






